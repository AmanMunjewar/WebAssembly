let exports;
WebAssembly.instantiateStreaming(
    fetch("streaming.wasm"), {}
).then(results => exports = results.instance.exports)

function add(){
    const a = document.querySelector("#a").value;
    const b = document.querySelector("#b").value;
    let result = exports.add(a,b);
    result = result.toFixed(2);

    document.querySelector("#ret")
        .innerHTML = `${a} + ${b} => ${result}<br/>`
}

function sub(){
    const a = document.querySelector("#a").value;
    const b = document.querySelector("#b").value;
    let result = exports.sub(a,b);
    result = result.toFixed(2);

    document.querySelector("#ret")
        .innerHTML = `${a} - ${b} => ${result}<br/>`
}

function mul(){
    const a = document.querySelector("#a").value;
    const b = document.querySelector("#b").value;
    let result = exports.mul(a,b);
    result = result.toFixed(2);

    document.querySelector("#ret")
        .innerHTML = `${a} * ${b} => ${result}<br/>`
}

function div(){
    const a = document.querySelector("#a").value;
    const b = document.querySelector("#b").value;
    let result = exports.div_l(a,b);
    result = result.toFixed(2);

    document.querySelector("#ret")
        .innerHTML = `${a} / ${b} => ${result}<br/>`
}

function collataz(){
    let num = document.querySelector("#c_num").value;
    document.querySelector("#sub")
        .innerHTML = ` `;

    while (true) {
        document.querySelector("#sub")
            .innerHTML += `=>${num} `
        if (num === 1) {
            break;
        }
        num = exports.collatz(num);
    }
}